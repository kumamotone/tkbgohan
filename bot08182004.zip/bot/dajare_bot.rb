# -*- coding: utf-8 -*-

require 'rubygems'
require 'net/https'
require 'oauth'
require 'json'
require 'pp'

require './access_token.rb'

module DajareBot
  class Base
    include DajareBot::AccessToken

    # botのscreen_nameを指定
    MY_SCREEN_NAME = "TKBGohanTest"

    # botのUser-Agentを指定
    BOT_USER_AGENT = "Auto Dajare Reply Program 1.0 @aquarla"

    # テキストファイルの置き場所を指定
    RANDOM_FILE_PATH = "./restaurants.txt"

    # 証明書のパスを指定
    HTTPS_CA_FILE_PATH = "./bb.cer"

    

    def initialize
      @consumer = OAuth::Consumer.new(
                                      CONSUMER_KEY,
                                      CONSUMER_SECRET,
                                      :site => 'https://api.twitter.com'
                                      )
      @access_token = OAuth::AccessToken.new(
                                             @consumer,
                                             ACCESS_TOKEN,
                                             ACCESS_TOKEN_SECRET
                                             )

      open(RANDOM_FILE_PATH) do |file|
        @dajares = file.readlines.collect{|line| line.strip}
      end
    end

    def connect
      uri = URI.parse("https://userstream.twitter.com/2/user.json?track=#{MY_SCREEN_NAME}")

      https = Net::HTTP.new(uri.host, uri.port)
      https.use_ssl = true
      https.ca_file = HTTPS_CA_FILE_PATH
      https.verify_mode = OpenSSL::SSL::VERIFY_PEER
      https.verify_depth = 5

      https.start do |https|
        request = Net::HTTP::Get.new(uri.request_uri)
        request["User-Agent"] = BOT_USER_AGENT
        request.oauth!(https, @consumer, @access_token)

        buf = ""
        https.request(request) do |response|
          response.read_body do |chunk|
            buf << chunk
            while (line = buf[/.+?(\r\n)+/m]) != nil
              begin
                buf.sub!(line,"")
                line.strip!
                status = JSON.parse(line)
              rescue
                break
              end
              yield status
            end
          end
        end
      end
    end

    def run
      loop do
        begin
          connect do |json|
            json.each do |j|
              puts j
            end
            if json['text']
              user = json['user']
              if (json['text'].match(/^@#{MY_SCREEN_NAME}\s*/))
                @access_token.post('/1/statuses/update.json', 'status' => "@#{user['screen_name']} #{random_dajare}", 'in_reply_to_status_id' => json['id'])
              end
            end
          end
        rescue Timeout::Error, StandardError
          puts "Twitterとの接続が切れた為、再接続します"
        end
      end
    end

    def random_dajare
      @dajares.shuffle.first
    end
  end
end

if $0 == __FILE__
  DajareBot::Base.new.run
end
