require 'sinatra'
require 'sinatra/reloader'
#require './twtest.rb'
require 'sparql/client'
set :environment, :production

def search_menu(subj)
     rs = []
     myclient = SPARQL::Client.new("http://localhost:8890/sparql/")
     q = "select distinct ?url ?x where { ?url <http://purl.org/dc/terms/subject> <http://ja.dbpedia.org/resource/" + subj  + "> .
    ?url <http://www.w3.org/2000/01/rdf-schema#label> ?x }"
     results = myclient.query(q)
     results.each do |solution|
     
       tmp = {
      "url" => String.new("#{solution[:url]}"),
      "label" => String.new("#{solution[:x]}") }  
      rs.push(tmp)
       # puts "pushed" + tmp
     end
     return rs
   end

def search_restaurant(subj)
     rs = []
     myclient = SPARQL::Client.new("http://localhost:8890/sparql/")
     q = "select distinct ?y where { ?s <http://purl.org/dc/terms/subject> <http://ja.dbpedia.org/resource/" + subj  + "> .
         ?s <http://tkbgohan.com/predicate#ismenuof> ?x .
         ?x <http://www.w3.org/2000/01/rdf-schema#label> ?y }"


     results = myclient.query(q)
     results.each do |solution|
       tmp = String.new("#{solution[:y]}")
       rs.push(tmp)
       puts "pushed" + tmp
     end
     return rs
   end

get '/' do
    erb :index
end

get '/search/:name' do |name|
  @name = name
  @res = search_menu(name)
  erb :search
end

