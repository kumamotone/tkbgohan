# -*- coding: utf-8 -*-
require 'rubygems'
require 'twitter'


  CONSUMER_KEY       = 'pqDGrK16Kbty5Dd4gamhcEka3'
  CONSUMER_SECRET    = '6OYuyyoWeLZs6gPGwAYbzZ2BYW0yz7qMqtjbItfsJBkE1rf8aG'
  ACCESS_TOKEN        = '2638738820-yaOqHAElDlVAl9vtFuWrZdBrBNoVHD1kil5DGFt'
  ACCESS_TOKEN_SECRET = 'Onel3CTVvFzcbryDrexDaifT3CE9lK1CRqONb37mWvBYc' 


Twitter.configure do |config|
  config.consumer_key       = CONSUMER_KEY
  config.consumer_secret    = CONSUMER_SECRET
  config.oauth_token        = ACCESS_TOKEN
  config.oauth_token_secret = ACCESS_TOKEN_SECRET
end

Twitter.update("TwitterGemテストなう")
