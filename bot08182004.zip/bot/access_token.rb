# -*- coding: utf-8 -*-

module DajareBot
  module AccessToken
    CONSUMER_KEY       = "pqDGrK16Kbty5Dd4gamhcEka3"
    CONSUMER_SECRET    = "6OYuyyoWeLZs6gPGwAYbzZ2BYW0yz7qMqtjbItfsJBkE1rf8aG"
    ACCESS_TOKEN        = "22638738820-yaOqHAElDlVAl9vtFuWrZdBrBNoVHD1kil5DGFt"
    ACCESS_TOKEN_SECRET = "Onel3CTVvFzcbryDrexDaifT3CE9lK1CRqONb37mWvBYc"
  end
end
